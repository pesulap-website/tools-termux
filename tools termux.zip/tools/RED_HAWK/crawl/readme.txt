This is a Part of RED HAWK

[ D E S C R I P T I O N ]

This directory contains mainly 4 files namely

- admin.ini
- backup.ini
- others.ini
- readme.txt

The first three files are mendetory for the RED HAWK scanner. These files have the list of files and directories which the scanner uses for crawling.

[ U S A G E   &   W A R N I N G S ]

• You can edit these files to put your own customized list.

• The 3 different ini files have list of different kinds of files and directories.
 - admin.ini : contains a list of admin pages or admin directories.
 - backup.ini : contains a list of commonly known backup files.
 - others.ini : basically all the other lists.

• Please NOTE the lists are separeted by COMMA "," any other type of separation used will cause error while crawling.
