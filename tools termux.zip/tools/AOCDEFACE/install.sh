apt upgrade && apt update -y
apt install python2
apt install figlet
apt install curl

